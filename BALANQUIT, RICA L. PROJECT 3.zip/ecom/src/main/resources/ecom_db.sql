
DROP DATABASE IF EXISTS ecom_db;
CREATE DATABASE ecom_db;

USE ecom_db;


CREATE TABLE user_tb (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL UNIQUE,
    password VARCHAR(100) NOT NULL,
    email VARCHAR(100) NOT NULL,
    roles VARCHAR(50) NOT NULL -- example: "ROLE_USER, ROLE_ADMIN"
);

-- Product Table
CREATE TABLE product_tb (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    description TEXT,
    price DECIMAL(10, 2) NOT NULL,
    quantity INT NOT NULL
);

-- Cart Table
CREATE TABLE cart_tb (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    FOREIGN KEY (user_id) REFERENCES user_tb(id)
);

-- CartItem Table
CREATE TABLE cart_item_tb (
    id INT AUTO_INCREMENT PRIMARY KEY,
    cart_id INT NOT NULL,
    product_id INT NOT NULL,
    quantity INT NOT NULL,
    FOREIGN KEY (cart_id) REFERENCES cart_tb(id),
    FOREIGN KEY (product_id) REFERENCES product_tb(id)
);

-- Data Insertion Example
-- Users
INSERT INTO user_tb (username, password, email, roles) VALUES ('john_doe', 'password123', 'john@example.com', 'ROLE_USER');
INSERT INTO user_tb (username, password, email, roles) VALUES ('admin', 'adminpass', 'admin@example.com', 'ROLE_ADMIN');

-- Products
INSERT INTO product_tb (name, description, price, quantity) VALUES ('Laptop', 'A powerful laptop for all your needs', 999.99, 10);
INSERT INTO product_tb (name, description, price, quantity) VALUES ('Smartphone', 'A feature-packed smartphone', 599.99, 20);

-- Cart for John Doe
INSERT INTO cart_tb (user_id) VALUES (1);

-- Cart Items for John Doe's cart
INSERT INTO cart_item_tb (cart_id, product_id, quantity) VALUES (1, 1, 1); -- 1 Laptop
