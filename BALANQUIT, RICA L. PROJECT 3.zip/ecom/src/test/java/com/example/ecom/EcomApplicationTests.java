package com.example.ecom;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EcomApplicationTests {

	@Test
	void contextLoads() {
	}

}
